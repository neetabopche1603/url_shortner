<?php $__env->startSection('content'); ?>
    <div class="container mt-lg-4">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e('Dashboard'); ?></div>

                    <div class="card-body">

                        <?php echo $__env->make('flashMessage', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div class="row mb-4">
                            <div class="col-md-4">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <h1 class="display-4"><?php echo e($urls->count()); ?></h1>
                                        <h5 class="card-title"><?php echo e('Total URLs'); ?></h5>
                                    </div>
                                    <div class="card-footer">
                                        <a href="<?php echo e(route('urls.index')); ?>"
                                            class="btn btn-sm btn-primary"><?php echo e('View All'); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <h1 class="display-4"><?php echo e($urls->sum('click_count')); ?></h1>
                                        <h5 class="card-title"><?php echo e('Total Clicks'); ?></h5>
                                    </div>
                                    <div class="card-footer">
                                        <a href="<?php echo e(route('urls.create')); ?>"
                                            class="btn btn-sm btn-success"><?php echo e('Create New URL'); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <h1 class="display-4"><?php echo e($urls->where('is_active', true)->count()); ?></h1>
                                        <h5 class="card-title"><?php echo e('Active URLs'); ?></h5>
                                    </div>
                                    <div class="card-footer">
                                        <?php
                                            $expiredCount = $urls
                                                ->filter(function ($url) {
                                                    return $url->expires_at && $url->expires_at->isPast();
                                                })
                                                ->count();
                                        ?>
                                        <?php if($expiredCount > 0): ?>
                                            <span
                                                class="badge bg-warning"><?php echo e(__(':count expired', ['count' => $expiredCount])); ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-success"><?php echo e('All Active Urls'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0"><?php echo e('Recent URLs'); ?></h5>
                            </div>
                            <div class="card-body">
                                <?php if($urls->isEmpty()): ?>
                                    <div class="alert alert-info">
                                        <p class="mb-0"><?php echo e('You haven\'t created any URLs yet.'); ?></p>
                                    </div>
                                    <div class="text-center mt-3">
                                        <a href="<?php echo e(route('urls.create')); ?>"
                                            class="btn btn-primary"><?php echo e('Create Your First URL'); ?></a>
                                    </div>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Short URL</th>
                                                    <th>Original URL</th>
                                                    <th>Created</th>
                                                    <th>Clicks</th>
                                                    <th>Status</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $urls->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <a href="<?php echo e(url('/s/' . $url->short_code)); ?>" target="_blank">
                                                                <?php echo e(url('/s/' . $url->short_code)); ?>

                                                            </a>
                                                        </td>
                                                        <td>
                                                            <span class="d-inline-block text-truncate"
                                                                style="max-width: 200px;" title="<?php echo e($url->original_url); ?>">
                                                                <?php echo e($url->original_url); ?>

                                                            </span>
                                                        </td>
                                                        <td><?php echo e($url->created_at->format('M d, Y')); ?></td>
                                                        <td><?php echo e($url->click_count); ?></td>
                                                        <td>
                                                            <?php if($url->is_active): ?>
                                                                <?php if($url->expires_at && $url->expires_at->isPast()): ?>
                                                                    <span
                                                                        class="badge bg-danger"><?php echo e(__('Expired')); ?></span>
                                                                <?php else: ?>
                                                                    <span
                                                                        class="badge bg-success"><?php echo e(__('Active')); ?></span>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <span class="badge bg-danger"><?php echo e(__('Inactive')); ?></span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <div class="btn-group" role="group">
                                                                <a href="<?php echo e(route('urls.view', $url)); ?>"
                                                                    class="btn btn-sm btn-info"><?php echo e(__('View')); ?></a>
                                                                <a href="<?php echo e(route('urls.edit', $url)); ?>"
                                                                    class="btn btn-sm btn-primary"><?php echo e(__('Edit')); ?></a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>

                                    <?php if($urls->count() > 5): ?>
                                        <div class="text-center mt-3">
                                            <a href="<?php echo e(route('urls.index')); ?>"
                                                class="btn btn-outline-primary"><?php echo e(('View All URLs')); ?></a>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Copy URL functionality
        document.querySelectorAll('.copy-btn').forEach(button => {
            button.addEventListener('click', function() {
                const text = this.getAttribute('data-clipboard-text');
                navigator.clipboard.writeText(text).then(() => {
                    const originalText = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-check"></i> <?php echo e(__('Copied!')); ?>';
                    this.classList.remove('btn-outline-primary');
                    this.classList.add('btn-success');

                    setTimeout(() => {
                        this.innerHTML = originalText;
                        this.classList.remove('btn-success');
                        this.classList.add('btn-outline-primary');
                    }, 2000);
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\url_shortener\resources\views/dashboard.blade.php ENDPATH**/ ?>